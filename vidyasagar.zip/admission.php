<!DOCTYPE html>
<html lang="en">
<head>
    <?php $title = 'Addmission - Vidya Sagar Preschool';
    @include('layouts/head.php') ?>
</head>
<body>
<?php @include('layouts/navbar.php') ?>

<section class="curri-banner">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-md-12">
                <h1 class="banner-title text-center">Admission</h1>
            </div>
        </div>
    </div>
</section>

</body>
</html>